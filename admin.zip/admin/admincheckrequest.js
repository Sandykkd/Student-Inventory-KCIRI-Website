
var tblUsers = document.getElementById('customers');
var databaseRef = firebase.database().ref('Request/');
var rowIndex = 1;
databaseRef.once('value', function (snapshot) {
    snapshot.forEach(function (childSnapshot) {
        childSnapshot.forEach(function (child) {

            var childKey = child.key;
            var childData = child.val();
            if (childData.status == "Submitted" ) {
                var row = tblUsers.insertRow(rowIndex);
                var cellId1 = row.insertCell(0);
                var cellId2 = row.insertCell(1);
                var cellName = row.insertCell(2);
                var cellName1 = row.insertCell(3);
                var cellName2 = row.insertCell(4);
                var cellName3 = row.insertCell(5);
                var cellName4 = row.insertCell(6);
                var cellName5 = row.insertCell(7);
                var cellName6 = row.insertCell(8);

                cellId1.appendChild(document.createTextNode(rowIndex));
                cellId2.appendChild(document.createTextNode(childData.rollnumber));
                cellName.appendChild(document.createTextNode(childData.type));
                cellName1.appendChild(document.createTextNode(childData.category));
                cellName2.appendChild(document.createTextNode(childData.model));
                cellName3.appendChild(document.createTextNode(childData.reqtime));
                cellName4.appendChild(document.createTextNode(childData.stock));
                cellName5.appendChild(document.createTextNode(childData.status));
                var status = childData.status;
                if (status == "Submitted") {

                    var myform = document.createElement("form");
                    submit = document.createElement("button");
                    submit.setAttribute("class", "update");
                    submit.type = "submit";
                    submit.value = "approve";
                    submit.innerHTML = "Approve";
                    myform.appendChild(submit);
                    myform.submit();
                    cellName6.appendChild(myform);
                }
                else if (status == "Approved") {

                    cellName6.appendChild(document.createTextNode("----"));
                    submit = document.createElement("button");

                }
                else {
                    cellName6.appendChild(document.createTextNode("----"));
                    submit = document.createElement("button");
                }



                submit.onclick = function () {
                    var status = "Approved";
                    var roll = childData.rollnumber;
                    var type = childData.type;
                    var cat = childData.category;
                    var mod = childData.model;
                    var stock = childData.stock;
                    var date = new Date();
                    var time = date.toLocaleString();
                    var pname = cat + '-' + mod;
                    firebase.database().ref("Request" + "/" + roll).child(pname).update({

                        apptime: time,
                        status: status
                    })



                    rowIndex = rowIndex + 1;
                }
            }
        })

    })
})

