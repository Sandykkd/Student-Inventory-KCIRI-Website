var tblUsers = document.getElementById('customers');
var databaseRef = firebase.database().ref('Request/');
var rowIndex = 1;
databaseRef.once('value', function (snapshot) {
    snapshot.forEach(function (childSnapshot) {
        childSnapshot.forEach(function(s1){
        var childData = s1.val();
        
        if(childData.status!="Submitted")
        {
        var row = tblUsers.insertRow(rowIndex);
        var cellId1 = row.insertCell(0);
        var cellId2 = row.insertCell(1);
        var cellName = row.insertCell(2);
        var cellName1 = row.insertCell(3);
        var cellName2 = row.insertCell(4);
        var cellName3 = row.insertCell(5);
        var cellName4 = row.insertCell(6);
        var cellName5 = row.insertCell(7);
        

        cellId1.appendChild(document.createTextNode(rowIndex));
        cellId2.appendChild(document.createTextNode(childData.rollnumber));
        cellName.appendChild(document.createTextNode(childData.type));
        cellName1.appendChild(document.createTextNode(childData.category));
        cellName2.appendChild(document.createTextNode(childData.model));
        cellName3.appendChild(document.createTextNode(childData.stock));
        cellName4.appendChild(document.createTextNode(childData.apptime));
        
        cellName5.appendChild(document.createTextNode(childData.status));
            rowIndex=rowIndex+1;
        }
    })
})
})