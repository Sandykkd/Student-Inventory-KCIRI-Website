function submitclick(){
    var cat=document.getElementById("type").value;
    var pcat=document.getElementById("pcat").value;
    var pnum=document.getElementById("pnum").value;
    var pname=pcat+'-'+pnum;
    var price=document.getElementById("pprice").value;
    var stock=document.getElementById("pstock").value;
    if(cat==="" && pcat==="" && pnum=="" && price==="" && stock==="")
    {
        window.alert("Correctly Enter Required Field");
    }
    else if(cat==="")
    {
        window.alert("Must Select Any category");
    }
    else if(pcat==="")
    {
        window.alert("Must Enter ProductCategory Field");
    }
    else if(pnum=="")
    {
        window.alert("Must Enter ProductModelnumber Field");
    }
    else if(price==="")
    {
        window.alert("Must Enter Productprice Field");
    }
    else if(stock==="")
    {
        window.alert("Must Enter Productstoke Field");
    }
    else{
        var date=new Date();
        var time=date.toLocaleString();
        firebase.database().ref("Products"+'/'+cat+'/'+pname).set({
        type:cat,
		category:pcat,
        model:pnum,
        price:price,
        stock:stock,
        time:time,
        
    });
    document.getElementById("sk").innerHTML=time;
    document.getElementById("pcat").value = "";
    document.getElementById("pnum").value = "";
    document.getElementById("pprice").value = "";
    document.getElementById("pstock").value = "";
    document.getElementById("type").selectedIndex = 0;
    location.href="search.html";
}
}
