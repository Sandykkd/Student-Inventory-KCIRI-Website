  var tblUsers = document.getElementById('ex-table');
  var databaseRef = firebase.database().ref('Products/');
  var rowIndex = 1;
  
  
databaseRef.once('value', function(snapshot) {
  snapshot.forEach(function(childSnapshot) {
    childSnapshot.forEach(function(snap){

  
  var childKey = snap.key;
  var childData = snap.val();
 
  var row = tblUsers.insertRow(rowIndex);
  var cellId1 = row.insertCell(0);
  var cellId2 = row.insertCell(1);
  var cellName = row.insertCell(2);
  var cellName1 = row.insertCell(3);
  var cellName2 = row.insertCell(4);
  var cellName3 = row.insertCell(5);
  var cellName4 = row.insertCell(6);


  cellId1.appendChild(document.createTextNode(rowIndex));
  cellId2.appendChild(document.createTextNode(childData.type));
  cellName.appendChild(document.createTextNode(childData.category));
  cellName1.appendChild(document.createTextNode(childData.model));
  cellName2.appendChild(document.createTextNode(childData.price));
  cellName3.appendChild(document.createTextNode(childData.stock));
  cellName4.appendChild(document.createTextNode(childData.time));
  
 rowIndex = rowIndex + 1;
  });
});
});
