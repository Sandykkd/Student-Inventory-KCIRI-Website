function submitclick() {
    var roll = document.getElementById("roll1").value;
    var cat = document.getElementById("type").value;
    var pcat = document.getElementById("pcat").value;
    var pnum = document.getElementById("pnum").value;
    var pname = pcat + '-' + pnum;
    var price = document.getElementById("pprice").value;

    if (cat === "" && pcat === "" && pnum == "" && price === "" && roll === "") {
        window.alert("Correctly Enter Required Field");
    }
    else if (roll === "") {
        window.alert("Enter your Roll Number");
    }
    else if (cat === "") {
        window.alert("Must Select Any category");
    }
    else if (pcat === "") {
        window.alert("Must Enter ProductCategory Field");
    }
    else if (pnum == "") {
        window.alert("Must Enter ProductModelnumber Field");
    }
    else if (price === "") {
        window.alert("Must Enter Productprice Field");
    }

    else {
        firebase.database().ref("Request/"+roll+"/"+pname).once('value').then(function (snapshort) {
            var oldstk=snapshort.val().stock;
            var newstk=parseInt(oldstk,10)+parseInt(price,10);
            firebase.database().ref("Request/"+roll+"/"+pname).update({
                stock:newstk
            })
            

        }).catch((error) => {

            
            var status = "Submitted";
            var date = new Date();
            var time = date.toLocaleString();
            firebase.database().ref("Request" + "/" + roll).child(pname).set({
                rollnumber: roll,
                type: cat,
                category: pcat,
                model: pnum,
                stock: price,
                reqtime: time,
                status: status
            })
        })


    }
    var databaseRef = firebase.database().ref("Products" + '/' + cat + '/' + pname);
    databaseRef.once('value', function (snapshot) {

        var typ = snapshot.val().type;
        var category = snapshot.val().category;
        var mod = snapshot.val().model;
        var pprice = snapshot.val().price;
        var stk = snapshot.val().stock;
        if (cat == typ && mod == pnum && category == pcat) {

            if (stk < price) {
                alert("Out of Stock ");
                location.href = "search.html";
            }
            else {
                var nk = stk - price;
                firebase.database().ref("Products" + '/' + cat + '/' + pname).update({

                    stock: nk,

                })
                location.href = "currentuserreq.html";
            }
        }
        else {
            alert("NK");
        }


    })


    document.getElementById("sk").innerHTML = time;
    document.getElementById("roll1").value = "";
    document.getElementById("pcat").value = "";
    document.getElementById("pnum").value = "";
    document.getElementById("pprice").value = "";
    document.getElementById("type").selectedIndex = 0;
}


