var roll=sessionStorage.username;
var tblUsers = document.getElementById('customers');
var databaseRef1 = firebase.database().ref('Products/');
var databaseRef = firebase.database().ref('Request/' + roll);
var type="";
var pname="";
var rowIndex = 1;
var myjson="";
databaseRef1.once('value',function(snapshot){
    myjson=snapshot.val();
})


databaseRef.once('value', function (snapshot) {
    snapshot.forEach(function (childSnapshot) {


        
        var childKey = childSnapshot.key;

        var childData = childSnapshot.val();
        if(childData.status !="Returned")
        {
        var row = tblUsers.insertRow(rowIndex);
        var cellId1 = row.insertCell(0);
        var cellId2 = row.insertCell(1);
        var cellName = row.insertCell(2);
        var cellName1 = row.insertCell(3);
        var cellName2 = row.insertCell(4);
        var cellName3 = row.insertCell(5);
        var cellName4 = row.insertCell(6);
        var cellName5 = row.insertCell(7);
        var cellName6 = row.insertCell(8);

        cellId1.appendChild(document.createTextNode(rowIndex));
        cellId2.appendChild(document.createTextNode(childData.rollnumber));
        cellName.appendChild(document.createTextNode(childData.type));
        cellName1.appendChild(document.createTextNode(childData.category));
        cellName2.appendChild(document.createTextNode(childData.model));
        cellName3.appendChild(document.createTextNode(childData.reqtime));
        cellName4.appendChild(document.createTextNode(childData.status));
        cellName5.appendChild(document.createTextNode(childData.stock));


        var status = childData.status;
        if (status == "Submitted") {

            cellName6.appendChild(document.createTextNode("Waiting for response"));
            submit = document.createElement("button");

        }
        else if (status == "Approved") {

            var myform = document.createElement("form");
            submit = document.createElement("button");
            submit.setAttribute("class", "update");
            submit.type = "submit";
            submit.value = "UPDATE";
            submit.innerHTML = "Return";
            myform.appendChild(submit);
            myform.submit();
            cellName6.appendChild(myform);
        }
        else {
            cellName6.appendChild(document.createTextNode("----"));
            submit = document.createElement("button");



        }
        submit.onclick = function () {
            var status = "Returned";
            var roll = childData.rollnumber;
            type = childData.type;
            var cat = childData.category;
            var mod = childData.model;
            var restock = childData.stock;
            var reqtime = childData.reqtime;
            var date = new Date();
            var time = date.toLocaleString();
            pname = cat + '-' + mod;
            
            myfun(type,pname,restock);
            firebase.database().ref("Request" + "/" + roll).child(pname).update({
              
                returntime: time,
                status: status
            })
            
            

        }
        rowIndex = rowIndex + 1;
    }
    })


})
function myfun(type,pname,restock)
{
    var temp;
    
    var astock;
    if(type=="BOARDS")
    {
        temp=myjson.BOARDS;
    }
    else if(type=="SENSORS")
    {
        temp=myjson.SENSORS;
    }
    else if(type=="MOTORS")
    {
        temp=myjson.MOTORS;
    }
    else if(type=="HARDWARES")
    {
        temp=myjson.HARDWARES;
    }
    else
    {
        temp=myjson.OTHERS
    }
    
    for(var key in temp)
    {   
        if(key.toString()==pname)
        {
            astock=temp[key].stock;
            
        }
        
    }
    
    var newstock=parseInt(astock,10)+parseInt(restock,10);
   
    firebase.database().ref("Products").child(type).child(pname).update({
        stock:newstock
    })
}

   
    



   
    


