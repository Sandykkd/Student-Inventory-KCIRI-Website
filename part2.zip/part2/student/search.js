var tblUsers = document.getElementById('ex-table');
var databaseRef = firebase.database().ref('Products/');
var rowIndex = 1;


databaseRef.once('value', function (snapshot) {
  snapshot.forEach(function (childSnapshot) {
    childSnapshot.forEach(function (snap) {


      var childKey = snap.key;
      var childData = snap.val();

      var row = tblUsers.insertRow(rowIndex);
      var cellId1 = row.insertCell(0);
      var cellId2 = row.insertCell(1);
      var cellName = row.insertCell(2);
      var cellName1 = row.insertCell(3);
      var cellName2 = row.insertCell(4);
      var cellName3 = row.insertCell(5);
      var cellName4 = row.insertCell(6);
      var cellName5 = row.insertCell(7);

      cellId1.appendChild(document.createTextNode(rowIndex));
      cellId2.appendChild(document.createTextNode(childData.type));
      cellName.appendChild(document.createTextNode(childData.category));
      cellName1.appendChild(document.createTextNode(childData.model));
      cellName2.appendChild(document.createTextNode(childData.price));
      cellName3.appendChild(document.createTextNode(childData.stock));
      cellName4.appendChild(document.createTextNode(childData.time));
      var myform = document.createElement("form");
      myform.action = "request1.html";
      myform.method = "get";

      ptype = document.createElement("input");
      ptype.type = "hidden"
      ptype.value = childData.type;
      ptype.name = "type";
      myform.appendChild(ptype);

      pcat = document.createElement("input");
      pcat.type = "hidden"
      pcat.value = childData.category;
      pcat.name = "cat";
      myform.appendChild(pcat);

      pmodel = document.createElement("input");
      pmodel.type = "hidden"
      pmodel.value = childData.model;
      pmodel.name = "model";
      myform.appendChild(pmodel);



      submit = document.createElement("button");
      submit.setAttribute("class", "update");
      submit.type = "submit";
      submit.value = "UPDATE";
      submit.innerHTML = "REQUEST";

      myform.appendChild(submit);
      myform.submit();
      cellName5.appendChild(myform);

      rowIndex = rowIndex + 1;
    });
  });
});