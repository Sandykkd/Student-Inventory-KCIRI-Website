<?php
$user=$_POST['username'];
$pass=$_POST['password'];
$email=$_POST['email'];
$phone=$_POST['phoneno'];
$con=mysqli_connect("localhost","root","","website");
$sql="INSERT INTO signup (username,email,phoneno,password) VALUES ('$user','$email','$phone','$pass')";
if(empty(($user) && ($pass) && ($email) && ($phone)))
{
	echo "Error";
}
else
{
	mysqli_query($con,$sql);
	header("location:index.html");
}

?>