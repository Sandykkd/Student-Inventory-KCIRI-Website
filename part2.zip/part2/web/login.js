function loginclick(){
	alert("NK");
	var name=document.getElementById("user").value;
	var pass=document.getElementById("pass").value;
	firebase.database().ref('Users/admin/').once('value').then(function(snapshort){
        var user=snapshort.val().DOB;
		if(user==pass)
		{
			alert("YES");
		}
		else
		{
			alert("NO");
		}


    });
}
	