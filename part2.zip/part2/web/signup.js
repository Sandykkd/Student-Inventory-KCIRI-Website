function register(){
    var roll=document.getElementById("roll").value;
    var dob=document.getElementById("dob").value;
    var email=document.getElementById("email").value;
    if(roll==="" && dob==="" && email=="")
    {
        window.alert("Correctly Enter Required Field");
    }
    else if(roll==="")
    {
        window.alert("RollNumber is required");
    }
    else if(dob==="")
    {
        window.alert("Dateofbirth is required");
    }
    else if(email=="")
    {
        window.alert("Email is required");
    }
   
    else{
        
    firebase.database().ref("Users/"+roll).set({
        RollNumber:roll,
        DOB:dob,
        Email:email,
        
    });


    
   
}
}
