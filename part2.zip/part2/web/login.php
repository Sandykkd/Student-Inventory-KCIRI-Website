<?php
$user=$_POST['username'];
$pass=$_POST['password'];
$con=mysqli_connect("localhost","root","","website");
$sql="INSERT INTO login (username,password) VALUES ('$user','$pass')";
$s="select id from signup where username='$user' and password='$pass'";
$result=mysqli_query($con,$s);
if(mysqli_num_rows($result)==1)
{
	mysqli_num_rows($con,$sql);
	header("location:dashboard.html");
}
else
{
	echo "Invaild user";
}
?>