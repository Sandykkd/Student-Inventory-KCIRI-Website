
    function encrypt() {
        
        var roll = document.getElementById("roll").value;
        var name = document.getElementById("name").value;
        var pass = document.getElementById("pass").value;
        var conpass = document.getElementById("conp").value;
        var res = name.toLowerCase();
        var pass1 = pass.length;


        var sp = res.indexOf(' ') !== -1;
        var num = roll.length;
        var n1 = roll.slice(0, 1);
        var n2 = roll.slice(1, 2);
        var s1 = roll.slice(2, 3);
        var s2 = roll.slice(3, 4);
        var s3 = roll.slice(4, 5);
        var n3 = roll.slice(5, 6);
        var n4 = roll.slice(6, 7);
        var n5 = roll.slice(7, 8);
        var regex = /^[A-Za-z ]+$/;
        var isValid = regex.test(name);
        if (roll === "" && name === "" && pass === "" && conpass === "") {
            alert("Enter required field");
        }
        else {



            if (num == '8') {
                if (isNaN(n1) && isNaN(n2)) {
                    alert("Invalid Rollnumber");
                }
                else {

                    if (isNaN(s1) && isNaN(s2) && isNaN(s3)) {
                        if (!isValid) {
                            alert("Name must be letters");
                        }
                        else {
                            if (pass1 == '6') {

                                if (pass == conpass) {
                                    

                                    var encrypted = CryptoJS.AES.encrypt(pass, "Secret Passphrase");
                                    var decrypted = CryptoJS.AES.decrypt(encrypted, "Secret Passphrase");
                                    alert("efreegg");
                                    
                                    firebase.database().ref("Users/" + roll).set({
                                        RollNumber: roll,
                                        Name: res,
                                        Password: decrypted.toString()


                                    });
                                }
                                else {
                                    alert("Password Mismatch");
                                }
                            }
                            else {
                                alert("Password must not be greater than 6");
                            }
                        }
                    }
                    else {
                        alert("Invalid Rollnumber");
                    }
                }
            }
            else {
                alert("Invalid Rollnumber");
            }
        }

        document.getElementById("roll").value = "";
        document.getElementById("name").value = "";
        document.getElementById("pass").value = "";
        document.getElementById("conp").value = "";


    }
    function loginclick()
		{
		location.href="login.html";
		}
