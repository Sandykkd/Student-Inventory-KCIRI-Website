 

alert("nk");

  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyDfnuowrvq7o4-tssiceRSHx76-ULctFHI",
    authDomain: "smartkciri-e22c3.firebaseapp.com",
    databaseURL: "https://smartkciri-e22c3.firebaseio.com",
    projectId: "smartkciri-e22c3",
    storageBucket: "smartkciri-e22c3.appspot.com",
    messagingSenderId: "243434967888",
    appId: "1:243434967888:web:786a0c8b5481edd5"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
